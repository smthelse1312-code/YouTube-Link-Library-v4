# YouTube Link Library 3.0 — Modern Edition

Android app source project. No YouTube Data API key, login, root, or backend required.

## Features
- Save YouTube watch, youtu.be, Shorts, and embed links locally
- Search saved titles and URLs
- Create categories and filter the library
- Favorite videos
- In-app YouTube IFrame embedded playback
- 60 seconds of active playback per preview session
- Full-screen player window
- Watch history and last playback position
- Export/import a JSON backup
- YouTube thumbnail images fetched from `img.youtube.com` (network required)
- Light/dark appearance toggle
- Custom launcher icon

## Important limitations
- Internet is required to load thumbnails and stream YouTube videos. Saved links and library data remain on-device.
- This app does not download YouTube video files for offline playback.
- Some videos cannot be embedded because of uploader restrictions, age restrictions, regional restrictions, or YouTube account requirements.
- Ads may still appear in YouTube's embedded player. This app does not promise to block YouTube video ads.
- Thumbnail is loaded from YouTube's public thumbnail image endpoint; title is entered by the user because this version does not call YouTube's Data API.

## Build
Use the GitHub Actions workflow supplied separately in the project instructions. Build with Java 17 and Gradle 8.11.1:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`
