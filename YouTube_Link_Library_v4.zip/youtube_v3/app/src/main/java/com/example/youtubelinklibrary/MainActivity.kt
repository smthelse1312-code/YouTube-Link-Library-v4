package com.example.youtubelinklibrary

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

private data class VideoItem(
    var id: String,
    var title: String,
    var url: String,
    var category: String = "Unsorted",
    var favorite: Boolean = false,
    var lastPosition: Int = 0,
    var lastPlayed: Long = 0L
)

class MainActivity : Activity() {
    private val items = mutableListOf<VideoItem>()
    private val categories = linkedSetOf("Unsorted", "Watch later", "Music", "Movies")
    private var dark = true
    private var filter = "All"
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var listBox: LinearLayout
    private lateinit var searchBox: EditText
    private val prefs by lazy { getSharedPreferences("library_v2", MODE_PRIVATE) }
    private val CREATE_BACKUP = 4101
    private val OPEN_BACKUP = 4102
    private val purple = Color.rgb(123, 55, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadData()
        dark = prefs.getBoolean("dark", true)
        buildUi()
    }

    private fun loadData() {
        try {
            val arr = JSONArray(prefs.getString("data", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(VideoItem(o.optString("id"), o.optString("title"), o.optString("url"), o.optString("category", "Unsorted"), o.optBoolean("favorite"), o.optInt("position"), o.optLong("played")))
            }
            val c = JSONArray(prefs.getString("categories", "[]") ?: "[]")
            for (i in 0 until c.length()) categories.add(c.getString(i))
        } catch (_: Exception) { }
    }

    private fun saveData() {
        val a = JSONArray()
        items.forEach { v -> a.put(JSONObject().put("id", v.id).put("title", v.title).put("url", v.url).put("category", v.category).put("favorite", v.favorite).put("position", v.lastPosition).put("played", v.lastPlayed)) }
        val c = JSONArray(); categories.forEach { c.put(it) }
        prefs.edit().putString("data", a.toString()).putString("categories", c.toString()).putBoolean("dark", dark).apply()
    }

    private fun bg() = if (dark) Color.rgb(9, 9, 20) else Color.rgb(245, 246, 252)
    private fun cardColor() = if (dark) Color.rgb(25, 23, 43) else Color.WHITE
    private fun textColor() = if (dark) Color.WHITE else Color.rgb(24, 24, 42)
    private fun muted() = if (dark) Color.rgb(174, 169, 198) else Color.rgb(105, 105, 125)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, radius: Int = 18, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg()) }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(20)) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("▶  YouTube Link Library", 23, true, textColor()))
        brand.addView(label("LƯU  •  QUẢN LÝ  •  MỞ BẰNG RVX", 10, true, muted()))
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(smallButton(if (dark) "☀" else "☾") { dark = !dark; saveData(); buildUi() })
        header.addView(smallButton("⋮") { showMoreMenu() })
        content.addView(header)

        searchBox = EditText(this).apply {
            hint = "⌕  Tìm kiếm video..."; textSize = 14f; singleLine = true
            setTextColor(textColor()); setHintTextColor(muted()); setPadding(dp(16), 0, dp(12), 0)
            background = shape(cardColor(), 24, if (dark) Color.rgb(54, 45, 80) else Color.LTGRAY)
        }
        val searchLp = LinearLayout.LayoutParams(-1, dp(50)); searchLp.topMargin = dp(20)
        content.addView(searchBox, searchLp)
        searchBox.addTextChangedListener(SimpleWatcher { renderList() })

        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val chipScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) }
        listOf("All", "Favorites", "History").forEach { key ->
            val b = smallButton(when (key) { "All" -> "⌂  Tất cả"; "Favorites" -> "♡  Yêu thích"; else -> "◷  Lịch sử" }) {
                filter = key; renderList(); buildChips(chips)
            }
            b.background = shape(if (filter == key) purple else cardColor(), 22)
            val lp = LinearLayout.LayoutParams(-2, dp(42)); lp.topMargin = dp(14); lp.rightMargin = dp(8)
            chips.addView(b, lp)
        }
        val chipLp = LinearLayout.LayoutParams(-1, -2); content.addView(chipScroll, chipLp)

        val section = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(20), 0, dp(10)) }
        section.addView(label("Video nổi bật", 19, true, textColor()), LinearLayout.LayoutParams(0, -2, 1f))
        section.addView(smallButton("＋ Thêm video") { addVideoDialog() })
        content.addView(section)
        val carousel = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; clipToPadding = false }
        val carouselRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        carousel.addView(carouselRow)
        val featured = visibleItems().take(10)
        if (featured.isEmpty()) {
            val empty = label("Thư viện đang trống. Nhấn ‘Thêm video’ để bắt đầu nhé!", 14, false, muted())
            empty.gravity = Gravity.CENTER; empty.setPadding(dp(18), dp(42), dp(18), dp(42))
            carouselRow.addView(empty)
        } else featured.forEach { item -> carouselRow.addView(featureCard(item)) }
        content.addView(carousel, LinearLayout.LayoutParams(-1, dp(330)))

        val shortcuts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("★\nYêu thích\n${items.count { it.favorite }}", "◷\nLịch sử\n${items.count { it.lastPlayed > 0 }}", "▤\nDanh mục\n${categories.size}", "⇧\nSao lưu\n& Khôi phục").forEachIndexed { index, txt ->
            val b = TextView(this).apply { text = txt; gravity = Gravity.CENTER; textSize = 12f; setTextColor(textColor()); background = shape(cardColor(), 18); setPadding(dp(4), dp(12), dp(4), dp(12)) }
            b.setOnClickListener { when (index) { 0 -> { filter = "Favorites"; renderList(); buildUi() }; 1 -> { filter = "History"; renderList(); buildUi() }; 2 -> addCategoryDialog(); else -> showBackupMenu() } }
            val lp = LinearLayout.LayoutParams(0, dp(92), 1f); lp.topMargin = dp(14); if (index > 0) lp.leftMargin = dp(7)
            shortcuts.addView(b, lp)
        }
        content.addView(shortcuts)

        val recentHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(22), 0, dp(10)) }
        recentHeader.addView(label(if (filter == "Favorites") "Video yêu thích" else if (filter == "History") "Lịch sử xem" else "Video gần đây", 19, true, textColor()), LinearLayout.LayoutParams(0, -2, 1f))
        recentHeader.addView(smallButton("＋ Danh mục") { addCategoryDialog() })
        content.addView(recentHeader)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listBox)

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8)); setBackgroundColor(cardColor()) }
        listOf("⌂\nTrang chủ", "▣\nThư viện", "＋\nThêm", "◈\nKhám phá", "⚙\nCài đặt").forEachIndexed { i, s ->
            val t = TextView(this).apply { text = s; gravity = Gravity.CENTER; textSize = 11f; setTextColor(if (i == 0) purple else muted()); setPadding(dp(4), dp(4), dp(4), dp(4)) }
            t.setOnClickListener { when (i) { 2 -> addVideoDialog(); 1 -> { filter = "All"; buildUi() }; 3 -> showCategoryPicker(); 4 -> showMoreMenu() } }
            bottom.addView(t, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(bottom, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        renderList()
    }

    private fun buildChips(row: LinearLayout) {
        row.removeAllViews()
        listOf("All" to "⌂  Tất cả", "Favorites" to "♡  Yêu thích", "History" to "◷  Lịch sử").forEach { (key, title) ->
            val b = smallButton(title) { filter = key; buildUi() }
            b.background = shape(if (filter == key) purple else cardColor(), 22)
            val lp = LinearLayout.LayoutParams(-2, dp(42)); lp.rightMargin = dp(8); row.addView(b, lp)
        }
    }

    private fun visibleItems(): List<VideoItem> {
        val q = if (::searchBox.isInitialized) searchBox.text.toString().trim().lowercase(Locale.ROOT) else ""
        return items.filter { (q.isEmpty() || it.title.lowercase().contains(q) || it.url.lowercase().contains(q)) && (filter != "Favorites" || it.favorite) && (filter != "History" || it.lastPlayed > 0L) }
            .sortedByDescending { it.lastPlayed }
    }

    private fun renderList() {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        val data = visibleItems()
        if (data.isEmpty()) {
            val t = label("Chưa có video phù hợp.", 14, false, muted()); t.gravity = Gravity.CENTER; t.setPadding(0, dp(28), 0, dp(28)); listBox.addView(t)
        }
        data.forEach { listBox.addView(videoRow(it)) }
        // Rebuild carousel on query/filter changes without resetting the search field.
        val scroller = content.getChildAt(4) as? HorizontalScrollView
        val row = scroller?.getChildAt(0) as? LinearLayout
        if (row != null) {
            row.removeAllViews(); data.take(10).forEach { row.addView(featureCard(it)) }
        }
    }

    private fun featureCard(item: VideoItem): View {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = shape(cardColor(), 22, if (dark) Color.rgb(76, 54, 125) else Color.LTGRAY); setPadding(dp(10), dp(10), dp(10), dp(10)) }
        val thumb = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = shape(Color.DKGRAY, 16) }
        card.addView(thumb, LinearLayout.LayoutParams(dp(270), dp(155)))
        loadThumbnail(item.url, thumb)
        val title = label(item.title.ifBlank { "YouTube video" }, 15, true, textColor()); title.maxLines = 2
        val titleLp = LinearLayout.LayoutParams(dp(270), -2); titleLp.topMargin = dp(10); card.addView(title, titleLp)
        val meta = label("${item.category}  •  YouTube", 11, false, muted()); card.addView(meta)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        actions.addView(smallButton("↗  Mở bằng RVX") { playVideo(item) }, LinearLayout.LayoutParams(0, dp(42), 1f))
        actions.addView(smallButton(if (item.favorite) "★" else "♡") { item.favorite = !item.favorite; saveData(); renderList() })
        val aLp = LinearLayout.LayoutParams(dp(270), -2); aLp.topMargin = dp(10); card.addView(actions, aLp)
        val lp = LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dp(12); card.layoutParams = lp
        return card
    }

    private fun videoRow(item: VideoItem): View {
        val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = shape(cardColor(), 16); setPadding(dp(10), dp(10), dp(8), dp(10)) }
        val thumb = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = shape(Color.DKGRAY, 10) }
        card.addView(thumb, LinearLayout.LayoutParams(dp(112), dp(76))); loadThumbnail(item.url, thumb)
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, dp(4), 0) }
        val t = label(item.title.ifBlank { "YouTube video" }, 14, true, textColor()); t.maxLines = 2; info.addView(t)
        info.addView(label(item.category + if (item.lastPlayed > 0) "  •  ${formatTime(item.lastPosition)}" else "", 11, false, muted()))
        card.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        card.setOnClickListener { playVideo(item) }
        card.setOnLongClickListener { editVideoDialog(item); true }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(9); card.layoutParams = lp
        return card
    }

    private fun label(s: String, size: Int, bold: Boolean, color: Int) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD) }
    private fun smallButton(s: String, action: () -> Unit) = TextView(this).apply {
        text = s; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(dp(12), dp(8), dp(12), dp(8)); background = shape(purple, 16); setOnClickListener { action() }
    }

    private fun videoId(url: String): String? = try {
        val u = Uri.parse(url.trim())
        when {
            u.host?.contains("youtu.be") == true -> u.lastPathSegment
            u.host?.contains("youtube.com") == true -> when {
                u.path?.startsWith("/watch") == true -> u.getQueryParameter("v")
                u.path?.startsWith("/shorts/") == true -> u.pathSegments.getOrNull(1)
                u.path?.startsWith("/embed/") == true -> u.pathSegments.getOrNull(1)
                else -> null
            }
            else -> null
        }?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{6,}")) }
    } catch (_: Exception) { null }

    private fun loadThumbnail(url: String, view: ImageView) {
        val id = videoId(url) ?: return
        view.tag = id
        thread {
            try {
                val c = URL("https://img.youtube.com/vi/$id/hqdefault.jpg").openConnection() as HttpURLConnection
                c.connectTimeout = 6000; c.readTimeout = 6000
                val bmp = c.inputStream.use { BitmapFactory.decodeStream(it) }; c.disconnect()
                runOnUiThread { if (view.tag == id && bmp != null) view.setImageBitmap(bmp) }
            } catch (_: Exception) { }
        }
    }

    private fun addVideoDialog(existing: VideoItem? = null) {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val title = EditText(this).apply { hint = "Tên video (có thể để trống)"; setText(existing?.title ?: "") }
        val url = EditText(this).apply { hint = "Dán link YouTube vào đây"; setText(existing?.url ?: ""); setSingleLine(true) }
        val cat = Spinner(this); cat.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories.toList())
        val initial = categories.toList().indexOf(existing?.category ?: "Unsorted"); if (initial >= 0) cat.setSelection(initial)
        panel.addView(title); panel.addView(url); panel.addView(cat)
        val dialog = AlertDialog.Builder(this).setTitle(if (existing == null) "Thêm video mới" else "Chỉnh sửa video").setView(panel)
            .setNegativeButton("Hủy", null).setNeutralButton("Kiểm tra link", null).setPositiveButton("Lưu video", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val id = videoId(url.text.toString().trim())
                if (id == null) toast("Link chưa hợp lệ. Hãy dán link YouTube đầy đủ.")
                else { toast("Link hợp lệ ✓"); if (title.text.isNullOrBlank()) title.setText("YouTube video") }
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val link = url.text.toString().trim(); val id = videoId(link)
                if (id == null) { toast("Không lưu được: link YouTube không hợp lệ"); return@setOnClickListener }
                val duplicate = items.firstOrNull { it.id == id && it !== existing }
                if (duplicate != null) { toast("Video này đã có trong thư viện"); return@setOnClickListener }
                if (existing == null) items.add(0, VideoItem(id, title.text.toString().trim().ifBlank { "YouTube video" }, link, cat.selectedItem.toString()))
                else { existing.title = title.text.toString().trim().ifBlank { "YouTube video" }; existing.url = link; existing.id = id; existing.category = cat.selectedItem.toString() }
                saveData(); dialog.dismiss(); filter = "All"; buildUi(); toast("Đã lưu video")
            }
        }
        dialog.show()
    }

    private fun editVideoDialog(item: VideoItem) = addVideoDialog(item)

    private fun playVideo(item: VideoItem) {
        item.lastPlayed = System.currentTimeMillis(); saveData(); renderList()
        val uri = Uri.parse(item.url)
        val candidates = listOf("app.revanced.android.youtube", "com.google.android.youtube.rvx", "com.google.android.youtube")
        var launched = false
        for (pkg in candidates) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, uri).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent); launched = true; break
            } catch (_: Exception) { }
        }
        if (!launched) {
            try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
            catch (_: Exception) { toast("Không tìm thấy ứng dụng mở link YouTube") }
        }
    }

    private fun addCategoryDialog() {
        val input = EditText(this).apply { hint = "Tên danh mục" }
        AlertDialog.Builder(this).setTitle("Tạo danh mục").setView(input).setNegativeButton("Hủy", null).setPositiveButton("Thêm") { _, _ ->
            val name = input.text.toString().trim(); if (name.isNotEmpty()) { categories.add(name); saveData(); buildUi() }
        }.show()
    }

    private fun showCategoryPicker() {
        val opts = categories.toTypedArray()
        AlertDialog.Builder(this).setTitle("Chọn danh mục").setItems(opts) { _, which ->
            val selected = items.filter { it.category == opts[which] }
            AlertDialog.Builder(this).setTitle(opts[which]).setItems(selected.map { it.title }.toTypedArray()) { _, index -> playVideo(selected[index]) }.setNegativeButton("Đóng", null).show()
        }.setNegativeButton("Đóng", null).show()
    }

    private fun showMoreMenu() {
        AlertDialog.Builder(this).setTitle("YouTube Link Library v4").setItems(arrayOf("Tạo danh mục", "Sao lưu / Khôi phục", "Chuyển giao diện sáng/tối")) { _, which ->
            when (which) { 0 -> addCategoryDialog(); 1 -> showBackupMenu(); 2 -> { dark = !dark; saveData(); buildUi() } }
        }.show()
    }

    private fun showBackupMenu() {
        AlertDialog.Builder(this).setTitle("Sao lưu dữ liệu").setItems(arrayOf("Xuất bản sao lưu", "Khôi phục từ tệp")) { _, which -> if (which == 0) backup() else restore() }.show()
    }

    private fun backup() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "youtube-link-library-backup.json") }
        startActivityForResult(i, CREATE_BACKUP)
    }
    private fun restore() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json" }
        startActivityForResult(i, OPEN_BACKUP)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        try {
            if (requestCode == CREATE_BACKUP) {
                contentResolver.openOutputStream(uri)?.use { it.write(exportJson().toByteArray()) }; toast("Đã xuất bản sao lưu")
            } else if (requestCode == OPEN_BACKUP) {
                val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: return
                val obj = JSONObject(raw); val arr = obj.getJSONArray("videos"); items.clear()
                for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); items.add(VideoItem(o.getString("id"), o.getString("title"), o.getString("url"), o.optString("category", "Unsorted"), o.optBoolean("favorite"), o.optInt("position"), o.optLong("played"))) }
                categories.clear(); categories.add("Unsorted"); val ca = obj.optJSONArray("categories") ?: JSONArray(); for (i in 0 until ca.length()) categories.add(ca.getString(i))
                saveData(); buildUi(); toast("Đã khôi phục dữ liệu")
            }
        } catch (e: Exception) { toast("Lỗi sao lưu: ${e.message}") }
    }

    private fun exportJson(): String {
        val a = JSONArray(); items.forEach { v -> a.put(JSONObject().put("id", v.id).put("title", v.title).put("url", v.url).put("category", v.category).put("favorite", v.favorite).put("position", v.lastPosition).put("played", v.lastPlayed)) }
        val c = JSONArray(); categories.forEach { c.put(it) }
        return JSONObject().put("version", 4).put("videos", a).put("categories", c).toString(2)
    }
    private fun formatTime(s: Int) = String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private class SimpleWatcher(val changed: () -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed() }
        override fun afterTextChanged(s: android.text.Editable?) {}
    }
}
