YOUTUBE LINK LIBRARY V4 - BUILD ON GITHUB ACTIONS

1. Upload this ZIP file to the root of your existing GitHub repository.
2. Your repository must already have a workflow at .github/workflows/build.yml that extracts the uploaded ZIP, OR replace that workflow with the .github/workflows/build.yml included in this ZIP.
3. In GitHub, open Actions and run "Build YouTube Link Library v4 APK" (or wait for the push workflow).
4. Open the completed workflow run and download the artifact named YouTube-Link-Library-v4-APK.
5. Extract the artifact ZIP and install app-debug.apk on Android.

No YouTube API key is required. Saved links and metadata remain stored locally on the device. Opening a video hands the URL to a compatible YouTube app; the app tries common RVX package names first and then falls back to Android's normal app chooser.

The v4 app upgrades the existing v3 preference storage and retains saved video records, favorites, categories and history. Keep a backup before installing any major update as a precaution.
